# World Languages 4.6.2

- Ajustada a reprodução de áudio para Android: aguarda a lista de vozes quando ela carrega de forma assíncrona, tenta selecionar voz italiana/inglesa compatível, retoma o mecanismo e apresenta mensagens de estado/erro.
- O áudio usa a síntese de voz do próprio navegador e depende do mecanismo Texto para fala instalado/ativo no Android.
- Mantidos o painel inicial, os cartões, as 400 novas expressões da 4.6, os favoritos, o perfil, o XP e as demais funcionalidades.
